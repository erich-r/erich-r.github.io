"""Exercise 2 - Dota 2 matches
"""

import os
import traceback

import matplotlib.pyplot as plt

DATASET = "dataset/dota2_players.csv"


# ALREADY WRITTEN FOR YOU, DON'T CHANGE IT.
def load_players(path):
    players = []
    with open(path, encoding="utf-8") as f:
        f.readline()  # skip the header
        for line in f:
            values = line.strip().split(";")
            players.append({
                "match_id": int(values[0]),
                "hero": values[1],
                "team": values[2],
                "win": values[3] == "True",
                "kills": int(values[4]),
                "deaths": int(values[5]),
                "assists": int(values[6]),
                "gold_per_min": int(values[7]),
            })
    return players


# T1
def hero_averages(players, hero):
    
    hero_averages = {
        "kills":0,
        "deaths":0,
        "assists":0
    }
    
    n = 0
    
    for player in players:
        player_hero = player['hero']
        
        if player_hero == hero:
            n+=1
            
            hero_averages["kills"] += player['kills']
            hero_averages["deaths"] += player['deaths']
            hero_averages["assists"] += player['assists']
    
    if n == 0:
        return hero_averages

    
    hero_averages['kills'] = round(hero_averages['kills'] / n,2)
    hero_averages['deaths'] = round(hero_averages['deaths'] / n,2)
    hero_averages['assists'] = round(hero_averages['assists'] / n,2)
    
    return hero_averages


# T2
def hero_win_rates(players, min_games=2000):
    # write your code here
    
    hero_stats = {} # hero -> [wins,total]
    
    for player in players:
        hero = player['hero']
        playerWon = player['win']
        
        if hero not in hero_stats:
            hero_stats[hero] = [0,0]
        
        hero_stats[hero][1] += 1
        if playerWon:
            hero_stats[hero][0] += 1
    
    to_purge = []
    
    for hero in hero_stats:
        _, n_games = hero_stats[hero]
        if n_games < min_games:
            to_purge.append(hero)
    
    for hero in to_purge:
        del(hero_stats[hero])
    
    hero_win_rates = {}
    
    for hero in hero_stats:
        hero_win_rates[hero] = round(100*(hero_stats[hero][0] / hero_stats[hero][1] ),1)
        
    return hero_win_rates
    


# T3
def plot_gold_per_min(players):
    
    gpm_winning_players = []
    gpm_losing_players = []

    for player in players:
        if player['win']:
            gpm_winning_players.append(player['gold_per_min'])
        else:
            gpm_losing_players.append(player['gold_per_min'])

    bins = range(100, 1001, 25)

    plt.hist(gpm_winning_players, bins=bins, alpha=0.6, color='green', label='Winning team')

    plt.hist(gpm_losing_players, bins=bins, alpha=0.6, color='red', label='Losing team')

    plt.title("Gold per Minute: Winning vs Losing Players")
    plt.xlabel("Gold per Minute")
    plt.ylabel("Number of Players")
    plt.legend()

    plt.savefig("gold_per_min.png")
    plt.show()
    
    

### YOU DON'T NEED TO TOUCH ANYTHING BELOW HERE..
# this is just to check the solution: run this file and look at the last line of each block:
#   OK         your result is correct
#   DIFFERENT  your result is not the expected one
#   NOT DONE   your function returns None
#   ERROR      your function crashed (the error message is shown)

def check(title, expected, function, *args, **kwargs):
    print("=" * 70)
    print(title)
    try:
        result = function(*args, **kwargs)
    except Exception:
        print(traceback.format_exc())
        print("-> ERROR: the code crashed, read the message above")
        return
    print("yours:   ", result)
    print("expected:", expected)
    if result is None:
        print("-> NOT DONE: the function returns None")
        return
    try:
        same = bool(result == expected)
    except Exception:
        same = False
    if same:
        print("-> OK")
    else:
        print("-> DIFFERENT")
        if type(result) != type(expected):
            print(f"   you returned a {type(result).__name__}, "
                  f"expected a {type(expected).__name__}")
        elif (isinstance(expected, list) and result and expected
              and type(result[0]) != type(expected[0])):
            print(f"   your list contains {type(result[0]).__name__}s, "
                  f"expected {type(expected[0]).__name__}s")


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    players = load_players(DATASET)

    check("Task 1: hero_averages(players, 'Pudge')",
          {"kills": 8.87, "deaths": 9.84, "assists": 12.39},
          hero_averages, players, "Pudge")
    check("Task 2: hero_win_rates(players)",
          {"Earthshaker": 51.9, "Queen of Pain": 42.6, "Shadow Fiend": 52.4,
           "Invoker": 49.9, "Tusk": 50.7, "Slardar": 56.4,
           "Windranger": 48.0, "Juggernaut": 51.3},
          hero_win_rates, players)
    
    plot_gold_per_min(players=players)