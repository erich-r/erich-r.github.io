"""Exercise 1 - Letterboxd ratings
"""

import os
import traceback

DATASET = "dataset/letterboxd_ratings.csv"

# a tiny ratings list in the same format that load_ratings must return
# it is used to test T2 and T3 even if Task 1 is not finished
SAMPLE_RATINGS = [
    {"user": "anna", "title": "Alien", "year": 1979, "runtime": 117,
     "genres": ["Horror", "Science Fiction"], "rating": 9},
    {"user": "anna", "title": "Amélie", "year": 2001, "runtime": 122,
     "genres": ["Comedy", "Romance"], "rating": 8},
    {"user": "anna", "title": "Barbie", "year": 2023, "runtime": 114,
     "genres": ["Comedy"], "rating": 6},
    {"user": "luca", "title": "Alien", "year": 1979, "runtime": 117,
     "genres": ["Horror", "Science Fiction"], "rating": 7},
    {"user": "luca", "title": "Barbie", "year": 2023, "runtime": 114,
     "genres": ["Comedy"], "rating": 4},
    {"user": "sara", "title": "Amélie", "year": 2001, "runtime": 122,
     "genres": ["Comedy", "Romance"], "rating": 10},
    {"user": "sara", "title": "Barbie", "year": 2023, "runtime": 114,
     "genres": ["Comedy"], "rating": 7},
]


# T1
def load_ratings(path="dataset/letterboxd_ratings.csv"):
    
    ratings = []
    
    with open(path,"r",encoding="utf-8") as f:
        f.readline()
        
        for line in f:
            # fields user;title;year;runtime;genres;rating
            # line = 14ltobias;#Alive;2020;98;Action|Horror|Thriller;7
            fields = line.split(";")
            user = fields[0]
            movie = fields[1]
            year = int(fields[2])
            runtime = int(fields[3])
            genres_str = fields[4]
            rating = int(fields[5])
            
            genre_list = genres_str.split("|")
            d = {
                "user":user,
                "title":movie,
                "year":year,
                "runtime":runtime,
                "rating":rating,
                "genres":genre_list
            }
            ratings.append(d)
            
    return ratings


# T2
def count_genres(ratings):
    
    genre_count = {}
    
    for rating in ratings:
        for genre in rating["genres"]:
            if genre not in genre_count:
                genre_count[genre] = 0
            genre_count[genre]+=1
    
    return genre_count


# T3
def top_movies(ratings, n=5, min_ratings=50):
    
    films = {} 
    
    for rating in ratings:
        if rating['title'] not in films:
            films[rating['title']] = []
        
        films[rating['title']].append(rating['rating'])
    
    avg_rating = []
    
    for movie in films:
        num_ratings = len(films[movie])
        if num_ratings < min_ratings:
            continue
        
        avg_rating.append(
            (movie,round(sum(films[movie]) / num_ratings,2),num_ratings)
            )
    
    avg_rating.sort(key=lambda x: -x[1])
    
    return avg_rating[:n]

### YOU DON'T NEED TO TOUCH ANYTHING BELOW HERE..
# this is just to check the solution: run this file and look at the last line of each block:
#   OK         your result is correct
#   DIFFERENT  your result is not the expected one
#   NOT DONE   your function returns None
#   ERROR      your function crashed (the error message is shown)

def check(title, expected, function, *args, **kwargs):
    print("=" * 70)
    print(title)
    try:
        result = function(*args, **kwargs)
    except Exception:
        print(traceback.format_exc())
        print("-> ERROR: the code crashed, read the message above")
        return
    print("yours:   ", result)
    print("expected:", expected)
    if result is None:
        print("-> NOT DONE: the function returns None")
        return
    try:
        same = bool(result == expected)
    except Exception:
        same = False
    if same:
        print("-> OK")
    else:
        print("-> DIFFERENT")
        if type(result) != type(expected):
            print(f"   you returned a {type(result).__name__}, "
                  f"expected a {type(expected).__name__}")
        elif (isinstance(expected, list) and result and expected
              and type(result[0]) != type(expected[0])):
            print(f"   your list contains {type(result[0]).__name__}s, "
                  f"expected {type(expected[0]).__name__}s")


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    print("\nON SAMPLE_RATINGS")
    check("Task 2: count_genres(SAMPLE_RATINGS)",
          {"Horror": 2, "Science Fiction": 2, "Comedy": 5, "Romance": 2},
          count_genres, SAMPLE_RATINGS)
    check("Task 3: top_movies(SAMPLE_RATINGS, n=2, min_ratings=2)",
          [("Amélie", 9.0, 2), ("Alien", 8.0, 2)],
          top_movies, SAMPLE_RATINGS, n=2, min_ratings=2)

    print("\nON THE FULL DATASET (needs Task 1)")
    try:
        ratings = load_ratings(DATASET)
    except Exception:
        print(traceback.format_exc())
        ratings = None
    if ratings is None:
        print("Task 1 is not finished or crashed: skipping the full dataset.")
    elif type(ratings) != list:
        check("Task 1: type(ratings)", list, type, ratings)
        print("load_ratings must return a list: skipping the full dataset.")
    else:
        check("Task 1: len(ratings)", 198186, len, ratings)
        check("Task 1: ratings[0]",
              {"user": "14ltobias", "title": "#Alive", "year": 2020,
               "runtime": 98, "genres": ["Action", "Horror", "Thriller"],
               "rating": 7},
              lambda: ratings[0])
        check("Task 2: count_genres(ratings)",
              {"Action": 41607, "Horror": 32671, "Thriller": 47705,
               "Comedy": 63216, "Drama": 90891, "Romance": 27140,
               "Science Fiction": 27032, "History": 7640, "Adventure": 35483,
               "Fantasy": 23645, "Documentary": 7305, "War": 4937,
               "Crime": 27347, "Mystery": 18922, "Family": 20506,
               "Music": 7391, "Animation": 15108, "Western": 2724,
               "TV Movie": 2609},
              count_genres, ratings)
        check("Task 3: top_movies(ratings)",
              [("Come and See", 9.45, 53), ("Parasite", 9.36, 171),
               ("12 Angry Men", 9.33, 91), ("Seven Samurai", 9.28, 54),
               ("The Godfather: Part II", 9.2, 76)],
              top_movies, ratings)
