"""Exercise 2 - Dota 2 matches
"""

import os
import traceback

import matplotlib.pyplot as plt

DATASET = "dataset/dota2_players.csv"


# ALREADY WRITTEN FOR YOU, DON'T CHANGE IT.
def load_players(path):
    players = []
    with open(path, encoding="utf-8") as f:
        f.readline()  # skip the header
        for line in f:
            values = line.strip().split(";")
            players.append({
                "match_id": int(values[0]),
                "hero": values[1],
                "team": values[2],
                "win": values[3] == "True",
                "kills": int(values[4]),
                "deaths": int(values[5]),
                "assists": int(values[6]),
                "gold_per_min": int(values[7]),
            })
    return players


# T1
def hero_averages(players, hero):
    # write your code here
    pass


# T2
def hero_win_rates(players, min_games=2000):
    # write your code here
    pass


# T3
def plot_gold_per_min(players):
    # write your code here
    pass

### YOU DON'T NEED TO TOUCH ANYTHING BELOW HERE..
# this is just to check the solution: run this file and look at the last line of each block:
#   OK         your result is correct
#   DIFFERENT  your result is not the expected one
#   NOT DONE   your function returns None
#   ERROR      your function crashed (the error message is shown)

def check(title, expected, function, *args, **kwargs):
    print("=" * 70)
    print(title)
    try:
        result = function(*args, **kwargs)
    except Exception:
        print(traceback.format_exc())
        print("-> ERROR: the code crashed, read the message above")
        return
    print("yours:   ", result)
    print("expected:", expected)
    if result is None:
        print("-> NOT DONE: the function returns None")
        return
    try:
        same = bool(result == expected)
    except Exception:
        same = False
    if same:
        print("-> OK")
    else:
        print("-> DIFFERENT")
        if type(result) != type(expected):
            print(f"   you returned a {type(result).__name__}, "
                  f"expected a {type(expected).__name__}")
        elif (isinstance(expected, list) and result and expected
              and type(result[0]) != type(expected[0])):
            print(f"   your list contains {type(result[0]).__name__}s, "
                  f"expected {type(expected[0]).__name__}s")


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    players = load_players(DATASET)

    check("Task 1: hero_averages(players, 'Pudge')",
          {"kills": 8.87, "deaths": 9.84, "assists": 12.39},
          hero_averages, players, "Pudge")
    check("Task 2: hero_win_rates(players)",
          {"Earthshaker": 51.9, "Queen of Pain": 42.6, "Shadow Fiend": 52.4,
           "Invoker": 49.9, "Tusk": 50.7, "Slardar": 56.4,
           "Windranger": 48.0, "Juggernaut": 51.3},
          hero_win_rates, players)
    
    plot_gold_per_min(players=players)